package com.example.ISA2021;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Isa2021Application {

	public static void main(String[] args) {
		SpringApplication.run(Isa2021Application.class, args);
	}

}
