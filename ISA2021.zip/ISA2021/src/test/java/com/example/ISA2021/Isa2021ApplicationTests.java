package com.example.ISA2021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Isa2021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
